﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excepcion2
{
   public class Alumno
    {
        //Se encapsulan los datos
        public string Nombre { get; set; }
        public string Matricula { get; set; }
        public int Semestre { get; set; }
        public string Carrera { get; set; }
        public int Calificacion { get; set; }
    }
}
